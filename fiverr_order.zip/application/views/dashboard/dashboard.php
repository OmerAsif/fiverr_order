<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<body>
    <div class ="row main">
        <div class="col-sm-3 col-md-2 col-lg-2 col-xl2 side-menue text-center text-primary">
            <nav class="navbar navbar-inverse side-menue">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand side-menue-content-width" href="#" style="margin: 9px;"> 
                            <i class="fa fa-tachometer"></i> Dashboard
                        </a>
                    </div>
                    <div class="collapse navbar-collapse" id="myNavbar">
                        <ul class="nav navbar-nav">
                            <li class="side-menue-content-width"><a href="#" id="homepage" ><i class="fa fa-home"></i> Home</a></li>
                            <li class="side-menue-content-width"><a href="#" id="requests_page"><i class="fa fa-building"></i> Property Setting</a></li> 
                            <li class="side-menue-content-width"><a href="#" id="setting"><i class="fa fa-cog" title="Edit"></i>  Settings</a></li>
                            <!--                            </ul>
                                                        <ul class="nav navbar-nav navbar-right">
                                                            <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                                                            <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                                                        </ul>-->
                    </div>
                </div>
            </nav>

        </div>
        <div class="col-md-10 col-lg-10 col-xl12 ">
            <div class="row">
                <div class="col-xs-12 col-sm-9 col-md-10 col-lg-10 col-xl-10" id="DashBoardBody">

                </div>

            </div>
        </div>
    </div>
